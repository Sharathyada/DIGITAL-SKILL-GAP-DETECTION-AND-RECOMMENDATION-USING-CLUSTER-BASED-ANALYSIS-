# File: dashboard_app.py (FINAL COMPLETE VERSION)

import streamlit as st
import pandas as pd
from pathlib import Path
import plotly.express as px
from src.clustering_api import run_pca_and_clustering 
from src.report_generator import generate_student_report 
import warnings
import numpy as np

warnings.filterwarnings("ignore", category=FutureWarning)

# --- GLOBAL HELPER FUNCTION ---
def get_index(item_name, options_list):
    """Safely retrieves the index of an item in a list, defaulting to 0 if not found."""
    try:
        return options_list.index(item_name)
    except ValueError:
        return 0 # Fallback

# --- Data Path Setup ---
ROOT_DIR = Path(__file__).resolve().parent
DATA_DIR = ROOT_DIR / "data"

# --- GUI SETUP ---
st.set_page_config(layout="wide", page_title="TDA Skill Gap Detector")
st.title("🧠 Skill Gap Detector & Curriculum Optimizer")
st.header("Project: Topological Data Analysis (TDA) Implementation") 
st.markdown("---")

# --- Sidebar Controls for Dynamic Clustering ---
st.sidebar.header("⚙️ Model Controls")

# 1. PCA Component Selector
selected_pca_n = st.sidebar.slider(
    '**PCA Components (Dimensions):**',
    min_value=2,
    max_value=10,
    value=3,
    step=1,
    help="Controls the variance retained and plot dimensions."
)

st.sidebar.markdown("---")

# 2. Algorithm Selector
selected_algo = st.sidebar.selectbox(
    '**Select Clustering Algorithm:**',
    options=['K-Means', 'K-Means++', 'Agglomerative Clustering', 'DBSCAN'],
    index=1,
    help="K-Means++ uses smart initialization. DBSCAN finds density-based clusters."
)

# 3. K Value Selector (Hidden for DBSCAN)
if selected_algo != 'DBSCAN':
    selected_k = st.sidebar.slider(
        '**Select Target Number of Clusters (K):**',
        min_value=2,
        max_value=10,
        value=4,
        step=1,
        help="The target number of groups for K-Means and Agglomerative."
    )
else:
    selected_k = 0 
    st.sidebar.info("DBSCAN finds clusters automatically.")

# --- Execute Dynamic Clustering and Load Data ---
@st.cache_data(show_spinner="Running PCA and Dynamic Clustering...", 
               hash_funcs={Path: str})
def get_dynamic_results(data_dir, k_value, algorithm, pca_components):
    return run_pca_and_clustering(data_dir, k_value, algorithm, pca_components)

# Run the model based on user selection
results = get_dynamic_results(DATA_DIR, selected_k, selected_algo, selected_pca_n)

if "error" in results:
    st.error(results["error"])
    st.stop()

df_pca = results["df_pca"]
df_centroids = results["df_centroids"]
ACCURACY_METRICS = results["metrics"]
all_student_ids = df_pca['student_id'].tolist()
df_pca['cluster_str'] = 'Cluster ' + df_pca['cluster'].astype(str)


# --- DYNAMIC METRIC ASSIGNMENT ---
PCA_VARIANCE = f"{ACCURACY_METRICS['pca_explained_variance']:.2f}%"
SILHOUETTE_SCORE = f"{ACCURACY_METRICS['silhouette_score']:.4f}"
CLUSTERS_FOUND = ACCURACY_METRICS['clusters_found']
SILHOUETTE_EXPLANATION = ACCURACY_METRICS['explanation']


## STEP 1 & 2: Data Preprocessing Display
st.subheader("STEP 1 & 2: Data Loading and Preprocessing")
with st.expander("Show Data Preparation Steps", expanded=False):
    try:
        df_raw = pd.read_csv(DATA_DIR / 'skill_manifold_10k.csv').head(20)
        df_processed_head = pd.read_csv(DATA_DIR / 'preprocessed_skill_data.csv').head(20)
        
        col_raw, col_processed = st.columns(2)
        
        with col_raw:
            st.caption("Raw Input Data (First 20 Rows)")
            st.dataframe(df_raw, use_container_width=True)
            
        with col_processed:
            st.caption("Preprocessed & Scaled Data (First 20 Rows)")
            st.dataframe(df_processed_head, use_container_width=True)
            st.info("Data is scaled between 0 and 1 before entering PCA/Clustering.")

    except FileNotFoundError:
        st.warning("Data files not found. Run `src/data_preprocessing.py` first.")
st.markdown("---")


## STEP 3 & 4: Dimensionality Reduction & Clustering
st.subheader("STEP 3 & 4: Dynamic Manifold Creation and Clustering (Accuracy Check)")
with st.expander("Show Accuracy Metrics and Manifold Creation Details", expanded=True):
    
    st.markdown("#### Unsupervised Accuracy Metrics:")
    col_a, col_b, col_c = st.columns(3)
    
    with col_a:
        st.metric(label=f"PCA Explained Variance ({selected_pca_n} Components)", 
                  value=PCA_VARIANCE)
    
    with col_b:
        st.metric(label="Silhouette Score", 
                  value=SILHOUETTE_SCORE)
        st.caption(SILHOUETTE_EXPLANATION)
        
    with col_c:
        k_display = f"K={selected_k}" if selected_algo != 'DBSCAN' else "N/A"
        st.metric(label="Method Used", value=f"{selected_algo}")
        st.caption(f"Target K: {k_display}. Found {CLUSTERS_FOUND} clusters.")

    st.caption("Cluster Centroids (The average skill profile of each competency group):")
    st.dataframe(df_centroids)
st.markdown("---")


## STEP 5 & 9: TDA Concept & Visualization Output
st.subheader("STEP 5 & 9: Topological Data Analysis (TDA) & Skill Manifold Map")

col_tda, col_viz = st.columns([1, 2])

with col_tda:
    st.markdown("5. **TDA Mapper Concept:** Conceptual execution to map skill proximity, revealing **missing transitions**.")
    st.caption("The gaps detected (right) correspond to missing edges in the conceptual skill topology.")
    st.markdown("---")
    st.subheader("TDA Topology Graph (Conceptual)")
    st.write("This would be the interactive TDA graph.")
    
with col_viz:
    st.markdown(f"9. **Visualization Dashboard:** Displaying results for **{selected_algo}**.")
    
    pca_component_options = [f'PC{i+1}' for i in range(selected_pca_n)]
    
    # --- AXES DEFINITION LOGIC (Handles 2D, 3D and dynamic axes selection) ---
    x_axis = 'PC1'
    y_axis = 'PC2'
    z_axis = None 
    
    if selected_pca_n == 2:
        # 2D Plot
        st.caption("2D Skill Manifold Map (Components: PC1, PC2)")
        x_axis, y_axis = 'PC1', 'PC2'
        
    elif selected_pca_n >= 3:
        # 3D Plot or Higher Dimensionality
        
        default_axes = ['PC1', 'PC2', 'PC3']
        default_axes = [ax for ax in default_axes if ax in df_pca.columns]
        
        while len(default_axes) < 3 and len(pca_component_options) > len(default_axes):
            default_axes.append(pca_component_options[len(default_axes)])

        st.caption(f"**Visualizing 3D projection from {selected_pca_n} PCA components.** Select 3 axes to view:")
        
        col_x, col_y, col_z = st.columns(3)
        
        x_axis = col_x.selectbox('X Axis', options=pca_component_options, index=get_index(default_axes[0], pca_component_options))
        y_axis = col_y.selectbox('Y Axis', options=pca_component_options, index=get_index(default_axes[1], pca_component_options))
        z_axis = col_z.selectbox('Z Axis', options=pca_component_options, index=get_index(default_axes[2], pca_component_options))
        
        st.caption(f"3D Skill Manifold Map (Axes: {x_axis}, {y_axis}, {z_axis})")
    
    # Trigger image generation for better understanding of the visualization
    

    # --- Plotly Chart Generation ---
    if selected_pca_n >= 3:
        fig_pca = px.scatter_3d(
            df_pca, 
            x=x_axis, 
            y=y_axis, 
            z=z_axis, 
            color='cluster_str', 
            title=f"3D Skill Manifold Map ({selected_algo}, Clusters: {CLUSTERS_FOUND})",
            hover_data=['student_id']
        )
    else: 
        fig_pca = px.scatter(
            df_pca, 
            x=x_axis, 
            y=y_axis, 
            color='cluster_str', 
            title=f"2D Skill Manifold Map ({selected_algo}, Clusters: {CLUSTERS_FOUND})",
            hover_data=['student_id']
        )
    st.plotly_chart(fig_pca, use_container_width=True)

st.markdown("---")


## STEP 6, 7, 8, 10: Core Logic and Final Report
st.subheader("STEP 6, 7, 8, 10: Skill Gap Computation and Automated Recombinator (Efficacy Output)")

st.markdown("The final steps combine the TDA structure with the dynamic clustering data to produce the personalized curriculum recommendation.")

# 8A: Backend Query Method
student_id_options = [''] + all_student_ids

selected_student_id = st.selectbox(
    '**STEP 8: Backend Query Method - Enter/Select Student ID to Fetch Report:**',
    options=student_id_options,
    index=get_index('S000004', student_id_options) 
)

# Report Generation (STEP 6, 7, 10)
if selected_student_id:
    st.markdown("### 📋 Student Gap Report")
    
    current_k_display = f"K={selected_k}" if selected_algo != 'DBSCAN' else "Automatic"
    
    st.info(f"Report based on current settings: **{selected_algo}** (Clusters Found: {CLUSTERS_FOUND}) and **{selected_pca_n} PCA components**.")
    
    st.caption("This report displays the outputs of **Step 6 (Computation), Step 7 (Explanation),** and **Step 10 (Recombinator)**.")
    
    report_text = generate_student_report(selected_student_id, DATA_DIR)
    
    st.markdown(report_text, unsafe_allow_html=True)