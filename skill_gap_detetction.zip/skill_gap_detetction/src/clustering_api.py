# File: src/clustering_api.py - FINAL CORRECTED VERSION

import pandas as pd
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.metrics import silhouette_score
import warnings
from pathlib import Path
import numpy as np

# Suppress KMeans warning for n_init
warnings.filterwarnings("ignore", category=FutureWarning)

def run_pca_and_clustering(data_dir: Path, k_value: int, algorithm: str, pca_components: int):
    """
    Performs PCA and the selected clustering algorithm, ensuring only numeric features are used.
    Saves the dynamic results to disk and returns metrics.
    """
    data_path = data_dir / 'preprocessed_skill_data.csv' 
    
    try:
        df_processed = pd.read_csv(data_path)
    except Exception as e:
        return {"error": f"Error loading processed data from: {data_path}. Details: {e}"}

    # --- FEATURE SELECTION FIX: Ensure X is ONLY numeric skill scores ---
    exclude_cols = ['student_id', 'cluster']
    feature_cols = [col for col in df_processed.columns if col not in exclude_cols]
    
    # X contains ONLY the skill scores (purely numeric)
    X = df_processed[feature_cols].select_dtypes(include=np.number).copy()
    
    if X.empty:
        return {"error": "No numeric features found for PCA after excluding IDs/labels. Check preprocessing."}

    # --- STEP 3: PCA (Dimensionality Reduction) ---
    # Check if we need to reduce n_components if it's greater than the number of features
    n_components_effective = min(pca_components, X.shape[1])
    pca = PCA(n_components=n_components_effective)
    
    X_pca = pca.fit_transform(X)
    explained_variance = sum(pca.explained_variance_ratio_)

    # Create dynamic column names (PC1, PC2, etc.) based on effective components
    df_pca_coords = pd.DataFrame(X_pca, columns=[f'PC{i+1}' for i in range(n_components_effective)])
    df_pca_coords['student_id'] = df_processed['student_id'].reset_index(drop=True)

    # --- STEP 4: Clustering (Dynamic Selection) ---
    clusters = None
    silhouette_avg = 0.0

    if 'K-Means' in algorithm:
        init_method = 'k-means++' if algorithm == 'K-Means++' else 'random'
        kmeans = KMeans(n_clusters=k_value, random_state=42, n_init='auto', init=init_method) 
        clusters = kmeans.fit_predict(X_pca)
        
    elif algorithm == 'Agglomerative Clustering':
        agg = AgglomerativeClustering(n_clusters=k_value)
        clusters = agg.fit_predict(X_pca)
        
    elif algorithm == 'DBSCAN':
        db = DBSCAN(eps=1.5, min_samples=10).fit(X_pca)
        clusters = db.labels_
    
    # Silhouette Score calculation logic
    cluster_labels_count = 0
    if clusters is not None:
        cluster_labels_set = set(clusters)
        cluster_labels_count = len(cluster_labels_set) - (1 if -1 in cluster_labels_set else 0)

        if cluster_labels_count >= 2 and len(X_pca) > cluster_labels_count:
            X_filtered = X_pca[clusters != -1]
            clusters_filtered = clusters[clusters != -1]
            if len(set(clusters_filtered)) >= 2:
                silhouette_avg = silhouette_score(X_filtered, clusters_filtered)
        
    # --- Prepare Results and Save to Disk (Centroids and Data) ---
    if clusters is not None:
        df_pca_coords['cluster'] = clusters
        df_clustered_temp = df_processed.copy()
        df_clustered_temp['cluster'] = clusters

        # Centroids calculation 
        df_for_centroids = df_clustered_temp[df_clustered_temp['cluster'] != -1] if algorithm == 'DBSCAN' else df_clustered_temp
        
        # Ensure only the original skill features are used for centroid calculation
        final_feature_cols = X.columns.tolist() 
        
        centroids = df_for_centroids.groupby('cluster')[final_feature_cols].mean()
            
        # Save dynamic files for the report generator to read
        df_pca_coords.to_csv(data_dir / 'dynamic_pca_coordinates.csv', index=False)
        centroids.reset_index().to_csv(data_dir / 'dynamic_cluster_centroids.csv', index=False)
        df_clustered_temp.to_csv(data_dir / 'dynamic_clustered_skill_data.csv', index=False)
    
    metrics = {
        "pca_explained_variance": round(explained_variance * 100, 2), 
        "silhouette_score": round(silhouette_avg, 4),
        "explanation": f"Score calculated with {algorithm} (K={k_value} or {cluster_labels_count} found) using {n_components_effective} PCA components.",
        "k_used": k_value,
        "clusters_found": cluster_labels_count,
        "algorithm": algorithm
    }

    return {
        "df_pca": df_pca_coords,
        "df_centroids": centroids.reset_index() if clusters is not None else pd.DataFrame(),
        "metrics": metrics
    }