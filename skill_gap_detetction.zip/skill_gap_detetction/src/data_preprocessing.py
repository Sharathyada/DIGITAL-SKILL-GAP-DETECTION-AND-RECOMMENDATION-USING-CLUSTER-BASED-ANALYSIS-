# File: src/data_preprocessing.py - FINAL CORRECTED VERSION

import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from pathlib import Path
import os
import sys
import numpy as np

def preprocess_data(input_dir: Path, output_dir: Path, input_filename: str):
    """
    Loads raw skill data, performs normalization, and saves the preprocessed output.
    """
    input_file = input_dir / input_filename
    
    if not input_file.exists():
        print(f"FATAL ERROR: Input file not found at {input_file}")
        sys.exit(1)

    print(f"✅ Loading data from: {input_file}")
    df = pd.read_csv(input_file)

    # Identify all numeric columns (int, float)
    numeric_features = df.select_dtypes(include=np.number).columns.tolist()
    
    # Exclude 'student_id' if it was read as a number (and any other identifier/label)
    features_to_scale = [col for col in numeric_features if col not in ['student_id']]
    
    if not features_to_scale:
        print("Error: No numeric features found to scale (excluding student_id).")
        sys.exit(1)
    
    print(f"Scaling the following {len(features_to_scale)} features: {features_to_scale[:5]}...")
    
    # Initialize scaler
    scaler = MinMaxScaler()
    
    # Apply scaling ONLY to the numeric features
    df[features_to_scale] = scaler.fit_transform(df[features_to_scale])
    
    # Save the preprocessed data (fixed output name for clustering API)
    output_file = output_dir / 'preprocessed_skill_data.csv'
    df.to_csv(output_file, index=False)
    
    print(f"✅ Preprocessed data saved to {output_file}")
    return output_file

if __name__ == '__main__':
    ROOT_DIR = Path(__file__).resolve().parent.parent
    DATA_DIR = ROOT_DIR / "data"
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    print("--- STEP 1 & 2: Preprocessing Data ---")
    preprocess_data(DATA_DIR, DATA_DIR, 'skill_manifold_10k.csv')