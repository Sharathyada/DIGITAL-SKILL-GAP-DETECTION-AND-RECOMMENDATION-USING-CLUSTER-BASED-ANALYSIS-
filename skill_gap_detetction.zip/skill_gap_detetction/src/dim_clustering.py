# # File: skill_gap_detection/src/dim_clustering.py - DYNAMIC METRIC CALCULATION

# import pandas as pd
# from sklearn.decomposition import PCA
# from sklearn.cluster import KMeans
#streamlit run dashboard.py
# from sklearn.metrics import silhouette_score
# import json
# from pathlib import Path

# def run_pca_and_clustering(data_path: Path, output_dir: Path):
#     """
#     STEP 3 & 4: Performs PCA for dimensionality reduction and K-Means clustering.
#     Also calculates and saves the key accuracy metrics.
#     """
#     try:
#         df_processed = pd.read_csv(data_path)
#     except Exception as e:
#         print(f"Error loading processed data: {e}")
#         return

#     # Select the 20 processed skill features (excluding ID and cluster)
#     feature_cols = [col for col in df_processed.columns if col not in ['student_id', 'cluster']]
#     X = df_processed[feature_cols].copy()

#     # --- STEP 3: PCA (Dimensionality Reduction) ---
#     pca = PCA(n_components=3)
#     X_pca = pca.fit_transform(X)
    
#     # Calculate Explained Variance (PCA Accuracy Metric)
#     explained_variance = sum(pca.explained_variance_ratio_)

#     df_pca_coords = pd.DataFrame(X_pca, columns=['PC1', 'PC2', 'PC3'])
#     # Ensure indices align for safe merging
#     df_pca_coords['student_id'] = df_processed['student_id'].reset_index(drop=True)

#     # --- STEP 4: Clustering (Unsupervised Learning) ---
#     K = 4
#     # CORRECTED: Use n_init='auto'
#     kmeans = KMeans(n_clusters=K, random_state=42, n_init='auto')
    
#     # CORRECTED: Cluster on the PCA-reduced features (X_pca)
#     clusters = kmeans.fit_predict(X_pca)
    
#     # CORRECTED: Calculate Silhouette Score on the PCA-reduced features (X_pca)
#     silhouette_avg = silhouette_score(X_pca, clusters)

#     # Save Metrics 
#     metrics = {
#         "pca_explained_variance": round(explained_variance * 100, 2), 
#         "silhouette_score": round(silhouette_avg, 4),
#         "silhouette_explanation": "A score closer to 1 indicates better cluster separation and cohesion. This score is calculated using the 3 PCA components for the k-means clustering.",
#         "k_value": K
#     }
#     with open(output_dir / 'accuracy_metrics.json', 'w') as f:
#         json.dump(metrics, f)

#     # Save clustered data and PCA coordinates
#     df_clustered = df_processed.copy()
#     df_clustered['cluster'] = clusters
#     df_clustered.to_csv(output_dir / 'clustered_skill_data.csv', index=False)
    
#     df_pca_coords['cluster'] = clusters
#     df_pca_coords.to_csv(output_dir / 'skill_pca_coordinates.csv', index=False)

#     # Calculate and save cluster centroids
#     centroids = df_clustered.groupby('cluster')[feature_cols].mean()
#     # Note: 'cluster' will be the index here, hence no index_col=0 is needed on load.
#     centroids.to_csv(output_dir / 'cluster_centroids.csv')

#     print(f"PCA and Clustering successfully completed. Saved {K} clusters and metrics.")


# if __name__ == '__main__':
#     # Set up paths for execution
#     ROOT_DIR = Path(__file__).resolve().parent.parent
#     DATA_DIR = ROOT_DIR / "data"
    
#     # FIX APPLIED HERE: Must match the output file name from data_preprocessing.py
#     INPUT_FILE = DATA_DIR / 'preprocessed_skill_data.csv' 
    
#     # The run_pca_and_clustering function is called with the corrected file name
#     run_pca_and_clustering(INPUT_FILE, DATA_DIR)
    
#     # The original file call below is removed/commented out:
#     # run_pca_and_clustering(DATA_DIR / 'skill_manifold_10k.csv', DATA_DIR)