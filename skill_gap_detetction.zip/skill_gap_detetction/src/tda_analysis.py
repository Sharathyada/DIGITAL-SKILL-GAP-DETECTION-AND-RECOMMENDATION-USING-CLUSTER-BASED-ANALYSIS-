# File: skill_gap_detection/src/tda_analysis.py
import pandas as pd
import numpy as np

# --- Conceptual TDA Classes ---

class SkillMapperTDA:
    """
    STEP 5: Applies TDA (Mapper) to identify isomorphic topological structures
    and output a conceptual TDA graph (nodes + edges).
    """
    def __init__(self, data: np.ndarray):
        self.data = data
        self.graph = {} 

    def build_graph(self):
        """Simulate the TDA Mapper algorithm to create the skill topology."""
        # 🚧 Conceptual TDA Graph structure 🚧
        
        self.graph['Node_Python'] = {'skill': 'Python', 'connections': ['Node_ML', 'Node_SQL', 'Node_DV']}
        self.graph['Node_ML'] = {'skill': 'Machine Learning', 'connections': ['Node_Prob', 'Node_Math']}
        self.graph['Node_Prob'] = {'skill': 'Probability', 'connections': ['Node_ML']} 
        self.graph['Node_Math'] = {'skill': 'Math', 'connections': ['Node_ML']}
        self.graph['Node_SQL'] = {'skill': 'SQL', 'connections': ['Node_DV']}
        self.graph['Node_DV'] = {'skill': 'Data Visualization', 'connections': []}
        
        return self.graph

class SkillGapDetector:
    """
    STEP 6: Compares student vector vs cluster centroid and uses TDA graph
    to find Weak Skills, Missing Prerequisites, and Broken Pathways.
    """
    def __init__(self, tda_graph: dict, centroids: pd.DataFrame, skill_cols: list):
        self.tda_graph = tda_graph
        self.centroids = centroids
        self.skill_cols = skill_cols

    def detect_gaps(self, student_vector: pd.Series, student_cluster: int):
        """Detects gaps using cluster analysis and TDA pathway rules."""
        
        gaps = []
        
        # 1. Cluster Centroid Comparison (Weak Skills vs. Peer Group)
        centroid_vector = self.centroids.loc[student_cluster]
        diffs = (centroid_vector - student_vector[self.skill_cols]).abs()
        weak_skills = diffs[diffs > diffs.quantile(0.75)].index.tolist()
        
        if weak_skills:
            gaps.append(f"**Weak Skills (Peer Comparison):** Detected skills significantly lagging behind your cluster peers: **{', '.join([s.replace('_skill', '').title() for s in weak_skills])}**.")
        
        # 2. TDA Pathway Check (Missing Prerequisites/Broken Pathways)
        
        # Example 1: Gap between Math/Prob and ML
        if student_vector['ml_skill'] > 0.6 and (student_vector['probability_skill'] < 0.4 or student_vector['math_skill'] < 0.4):
            gaps.append("**Broken Pathway (Math -> ML):** High proficiency in ML, but insufficient foundational Math/Probability skills. The **minimal bridging content** required is a focus on **Probability Theory** to stabilize this transition edge.")
        
        # Example 2: Gap for cross-disciplinary reconstruction (Python -> SQL)
        if student_vector['python_skill'] > 0.7 and student_vector['sql_skill'] < 0.3:
            gaps.append("**Cross-Domain Gap (Python -> SQL):** Strong programming foundation (Python), but a large gap in **SQL** proficiency. This prevents efficient **skill pathway reconstruction** for database-centric projects.")
            
        # Example 3: Behavioral Gap (Consistency)
        if student_vector['avg_accuracy'] > 0.7 and student_vector['consistency'] < 0.4:
             gaps.append("**Behavioral Bottleneck:** High task accuracy, but low consistency. This suggests **bottlenecks** in learning paths due to erratic study habits or frequent breaks, affecting retention.")
             
        return gaps