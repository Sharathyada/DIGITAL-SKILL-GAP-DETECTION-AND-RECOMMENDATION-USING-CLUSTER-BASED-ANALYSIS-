
        if cluster_labels_count >= 2 and len(X_pca) > cluster_labels_count:
            X_filtered = X_pca[clusters != -1]
            clusters_filtered = clusters[clusters != -1]
            if len(set(clusters_filtered)) >= 2:
                silhouette_avg = silhouette_score(X_filtered, clusters_filtered)
        
    # --- Prepare Results and Save to Disk (Centroids and Data) ---
    if clusters is not None:
        df_pca_coords['cluster'] = clusters
        df_clustered_temp = df_processed.copy()
        df_clustered_temp['cluster'] = clusters

        # Centroids calculation 
        df_for_centroids = df_clustered_temp[df_clustered_temp['cluster'] != -1] if algorithm == 'DBSCAN' else df_clustered_temp
        
        # Ensure only the original skill features are used for centroid calculation
        final_feature_cols = X.columns.tolist() 
        
        centroids = df_for_centroids.groupby('cluster')[final_feature_cols].mean()
            
        # Save dynamic files for the report generator to read
        df_pca_coords.to_csv(data_dir / 'dynamic_pca_coordinates.csv', index=False)
        centroids.reset_index().to_csv(data_dir / 'dynamic_cluster_centroids.csv', index=False)
