# File: skill_gap_detection/src/viz_dashboard.py
import pandas as pd
import plotly.express as px

def create_skill_manifold_map(df_pca: pd.DataFrame):
    """
    STEP 9: Generates the interactive 3D PCA visualization (Skill Manifold Map).
    """
    
    # Ensure cluster is categorical for distinct colors
    df_pca['cluster'] = df_pca['cluster'].astype(str) 

    # Plotly is used for the interactive 3D scatterplot
    fig = px.scatter_3d(
        df_pca, 
        x='PC1', 
        y='PC2', 
        z='PC3',
        color='cluster',
        symbol='cluster',
        hover_name='student_id',
        title='3D Skill Manifold Map (PCA: PC1, PC2, PC3)',
        color_discrete_sequence=px.colors.qualitative.Vivid
    )
    
    fig.update_traces(marker=dict(size=4))
    
    return fig

# This file is primarily used for the function called in dashboard_app.py